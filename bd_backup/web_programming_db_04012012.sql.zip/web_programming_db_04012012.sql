-- phpMyAdmin SQL Dump
-- version 3.4.5deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 04, 2012 at 12:55 PM
-- Server version: 5.1.58
-- PHP Version: 5.3.6-13ubuntu3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `web_programming`
--
CREATE DATABASE `web_programming` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `web_programming`;

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `event_location` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_description` text COLLATE utf8_unicode_ci,
  `post_date` date NOT NULL,
  `post_time` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

CREATE TABLE IF NOT EXISTS `file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `folder` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `extension` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `size` float NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `post_date` date NOT NULL,
  `post_time` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `label` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `ord` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `label`, `status`, `ord`) VALUES
('home', 'Sessions', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `parcours`
--

CREATE TABLE IF NOT EXISTS `parcours` (
  `id` varchar(10) NOT NULL,
  `level_id` varchar(10) NOT NULL,
  `ord` float NOT NULL,
  `name` varchar(150) NOT NULL DEFAULT '',
  `name_abv` varchar(50) NOT NULL DEFAULT '',
  `responsable_id` int(5) DEFAULT NULL,
  `objective` text,
  `access_condition` text,
  `perspective` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `parcours`
--

INSERT INTO `parcours` (`id`, `level_id`, `ord`, `name`, `name_abv`, `responsable_id`, `objective`, `access_condition`, `perspective`) VALUES
('1', 'LA', -4, 'Economie - Finance Internationale', 'LA Economie - Fin Inter', NULL, '<p>Cette formation appliquée de 3 ans après le baccalauréat a pour but d''apporter aux étudiants une formation généraliste en Sciences Economiques et dans une moindre mesure en Sciences de Gestion plus précisément en finance internationale qui leur permettra de poursuivre leurs études en intégrant éventuellement un master de Sciences Economiques ou de Sciences de Gestion. Elle a aussi pour objectif de préparer les étudiants à devenir des futurs cadres compétents à l''échelle locale ou à l''international. \r\nCette formation vise ainsi à :</p>\r\n<ul>\r\n<li>Acquérir une culture générale et à consolider des connaissances en sciences économiques et en sciences de gestion,</li>\r\n<li>Assurer une maîtrise de l''analyse micro/macro économique de l''environnement, connaissance des systèmes financiers et monétaires,</li>\r\n<li>Acquérir des techniques du commerce international, </li>\r\n<li>Bénéficier d''une très bonne maîtrise orale et écrite des langues comme l''anglais d''affaire,</li>\r\n<li>Maîtriser l''outil informatique. </li>\r\n</ul>', NULL, '<ul>\r\n<li>Possibilité de poursuite d''étude en en intégrant éventuellement un master de Sciences Economiques ou de Sciences de Gestion</li>\r\n<li>L''insertion professionnelle est multiple et variée : économistes, conseillers, chargés d''études ou de projets, gestionnaires,...dans les entreprises privées, les administrations, les banques, les assurances, les organismes professionnels etc.</li>\r\n</ul>'),
('3', 'LA', -2.95312, 'Economie - Gestion Quantitative', 'LA Economie - EGQ', NULL, '<p>Cette formation appliquée de 3 ans après le baccalauréat a pour but d''apporter aux étudiants une formation généraliste en Sciences Economiques et dans une moindre mesure en Sciences de Gestion plus précisément en gestion quantitative. Elle a aussi pour objectif de préparer les étudiants à devenir des futurs cadres compétents à l''échelle locale ou à l''international. \r\nCette formation vise ainsi à acquérir :</p>\r\n\r\n<ul>\r\n<li>Acquérir une culture générale et à consolider des connaissances en sciences économiques et en sciences de gestion,</li>\r\n<li>Assurer une maîtrise des méthodes et outils du management de la qualité,  et connaissance des techniques statistiques,</li>\r\n<li>Bénéficier d''une très bonne maîtrise orale et écrite des langues comme l''anglais d''affaire,</li>\r\n<li>Maîtriser l''outil informatique. </li>\r\n</ul>', NULL, '<ul>\r\n<li>Possibilité de poursuite d''étude en en intégrant éventuellement un master de Sciences Economiques ou de Sciences de Gestion.</li>\r\n<li>L''insertion professionnelle est multiple et variée : économistes, conseillers, chargés d''études ou de projets, gestionnaires,...dans les entreprises privées, les administrations, les banques, les assurances, les organismes professionnels etc.</li>\r\n</ul>'),
('4', 'LF', -2.05469, 'Economie - Monnaie, Finance et Banques', 'LF Economie - MFB', NULL, '<p>Cette formation fondamentale de 3 ans après le baccalauréat a pour but d''apporter aux étudiants une formation généraliste en Sciences Economiques et dans une moindre mesure en Sciences de Gestion. Elle a aussi pour objectif de préparer les étudiants à devenir des futurs cadres compétents à l''échelle locale ou à l''international. Cette formation vise ainsi à :</p>\r\n<ul>\r\n<li>Acquérir une culture générale et à consolider des connaissances en sciences économiques, de maîtriser la micro et la macro économie,</li>\r\n<li>Assurer une maîtrise des méthodes et outils du diagnostic financier des entreprises, des banques et des assurances, </li>\r\n<li>Bénéficier d''une très bonne maîtrise orale et écrite des langues comme l''anglais d''affaire,</li>\r\n<li>Maîtriser l''outil informatique.</li>\r\n</ul>', NULL, '<ul>\r\n<li>Poursuivre les études en intégrant un master de Sciences Economiques</li>\r\n<li>L''insertion professionnelle est multiple et variée : économistes, conseillers, chargés d''études ou de projets,...dans les entreprises privées, les administrations, les banques, les assurances, les organismes professionnels etc.</li>\r\n</ul>'),
('5', 'LF', -0.902345, 'Economie - Mathématiques et Econométrie', 'LF Economie - EME', NULL, '<p>Cette formation appliquée de 3 ans après le baccalauréat a pour but d''apporter aux étudiants une formation généraliste en Sciences de Gestion et plus particulièrement en Sciences Comptables. Elle a aussi pour objectif de préparer les étudiants à devenir des futurs cadres compétents à l''échelle locale ou à l''international. \r\nCette formation appliquée vise ainsi à :</p>\r\n<ul>\r\n<li>Acquérir une culture générale et à consolider des connaissances en Sciences de Gestion et Sciences Comptables, </li>\r\n<li>Maîtriser les principes et les normes comptables en tenant compte du cadre légal en la matière,</li>\r\n<li>Assurer une maîtrise des aspects juridiques et fiscaux des organisations tunisiennes,\r\nBénéficier d''une très bonne maîtrise orale et écrite des langues comme l''anglais d''affaire,</li>\r\n<li>Maîtriser l''outil informatique.</li>\r\n</ul>', NULL, '<ul>\r\n<li>Poursuite des études en intégrant éventuellement un master de Sciences de Gestion.</li>\r\n<li>L''insertion professionnelle est multiple et variée : aides comptables, conseillers en comptabilité, gestionnaires, chargés d''études ou de projets,...dans les entreprises privées, les administrations, les banques, les assurances, les organismes professionnels etc.</li>\r\n</ul>'),
('6', 'LF', -0.100462, 'Economie - Economie des Affaires', 'LF Economie -  EA', NULL, '<p>Cette formation fondamentale de 3 ans après le baccalauréat a pour but d''apporter aux étudiants une formation généraliste en Sciences Economiques et dans une moindre mesure en Sciences de Gestion. Elle a aussi pour objectif de préparer les étudiants à devenir des futurs cadres compétents à l''échelle locale ou à l''international. \r\nCette formation vise ainsi à :</p>\r\n<ul>\r\n<li>Acquérir une culture générale et à consolider des connaissances en sciences économiques, de maîtriser la micro et la macro économie, </li>\r\n<li>Assurer une maîtrise des modèles économiques des organisations dans un environnement d''affaires local et international, </li>\r\n<li>Bénéficier d''une très bonne maîtrise orale et écrite des langues comme l''anglais d''affaire,</li>\r\n<li>Maîtriser l''outil informatique. </li>\r\n</ul>', NULL, '<ul>\r\n<li>Poursuivre les études en intégrant un master de Sciences Economiques.</li>\r\n<li>L''insertion professionnelle est multiple et variée : économistes, conseillers, chargés d''études ou de projets,...dans les entreprises privées, les administrations, les banques, les assurances, les organismes professionnels etc.</li>\r\n</ul>'),
('7', 'LA', 0.724459, 'Gestion - Comptabilité de Gestion', 'LA Gestion - Compta', NULL, '<p>Cette formation appliquée de 3 ans après le baccalauréat a pour but d''apporter aux étudiants une formation généraliste en Sciences de Gestion et plus particulièrement en Sciences Comptables. Elle a aussi pour objectif de préparer les étudiants à devenir des futurs cadres compétents à l''échelle locale ou à l''international. \r\nCette formation appliquée vise ainsi à :</p>\r\n<ul>\r\n<li>Acquérir une culture générale et à consolider des connaissances en Sciences de Gestion et Sciences Comptables, </li>\r\n<li>Maîtriser les principes et les normes comptables en tenant compte du cadre légal en la matière,</li>\r\n<li>Assurer une maîtrise des aspects juridiques et fiscaux des organisations tunisiennes,\r\nBénéficier d''une très bonne maîtrise orale et écrite des langues comme l''anglais d''affaire,</li>\r\n<li>Maîtriser l''outil informatique. </li>\r\n</ul>', NULL, '<ul>\r\n<li>Poursuite des études en intégrant éventuellement un master de Sciences de Gestion.</li>\r\n<li>L''insertion professionnelle est multiple et variée : aides comptables, conseillers en comptabilité, gestionnaires, chargés d''études ou de projets,...dans les entreprises privées, les administrations, les banques, les assurances, les organismes professionnels etc.</li>\r\n</ul>'),
('8', 'LA', 4.14111, 'Gestion - Gestion des Ressources Humaines', 'LA Gestion - GRH', NULL, NULL, NULL, NULL),
('9', 'LA', 5.31909, 'Gestion - Administration des Affaires', 'LA Gestion - Admin Aff', NULL, NULL, NULL, NULL),
('10', 'MP', 9.2944, 'Ingénierie Economique et Financière', 'MP Ing Eco Financière', 17, 'L’objectif du Mastère Ingénierie Economique et Financière est de former des économistes maîtrisant les principales techniques quantitatives et d’aide à la décision (statistique, économétrie, analyse des données, informatique de décision,…) et disposant de solides connaissances sur leurs champs d’application. Cette formation répondra aux besoins d''analyse et d''expertise qu''expriment les entreprises, les cabinets de consultants et un certain nombre d''organismes en matière d’analyse et recueil de l''information économique, prévisions et études de marché, modélisation et analyse des risques.', 'Ce mastère s''adresse à des diplômés titulaires d''une licence appliquée en économie et gestion quantitative, d’une licence fondamentale en économie ou d’une licence en informatique appliquée à la gestion.\r\n<br />\r\nUne priorité est donnée aux étudiants de la Faculté des Sciences Economiques et de Gestion de Nabeul, mais la formation est ouverte aux candidats extérieurs ayant un niveau équivalent.\r\n<br />\r\nLa formation est aussi ouverte aux  étudiants issus des écoles d’ingénieur ayant une formation équivalente en analyse économique (ESSAI, ENIT, EPT, etc.)', 'Les futurs diplômés seront au cœur des métiers d''aide à la décision. Ils occuperont des postes de responsabilité aux centres de recherche en économie appliquée (INS, IEQ,…), au sein des administrations, dans des organismes nationaux et internationaux ainsi que dans différents types d''entreprises (banques, sociétés d''assurance, grandes entreprises industrielles et commerciales, petites et moyennes entreprises de services, bureaux d''étude et de conseil, etc.)\r\n<br />\r\nPour les meilleurs étudiants, ce cursus peut déboucher sur la préparation d''une thèse et l''entrée dans une carrière universitaire.'),
('11', 'MP', 9.53, 'Marketing Touristique', 'MP Marketing Touristique', 4, 'Cette formation permet de former des professionnels capables d’intégrer toutes les fonctions de gestion du tourisme (élaboration, réalisation et suivi de projets touristiques, analyse d’un secteur, management d’une équipe...). Les objectifs professionnels sont fondamentaux. Il s’agit de préparer de futurs managers aptes à un réel pouvoir de décision. \r\nLa première compétence demeure la bonne maîtrise des langues. En second, les compétences juridiques et économiques doivent permettre de maîtriser les données liées aux conjonctures. La maîtrise des techniques de gestion et de communication est aussi essentielle. Et bien sûr, une solide spécialisation en produits et environnements touristiques s’impose.\r\n<br />\r\nA la fin du parcours l''étudiant doit :\r\n<ul>\r\n<li>avoir acquis les connaissances essentielles en matière de gestion des entreprises ;</li>\r\n<li>être capable de replacer ces aspects dans un cadre de réflexion plus large, incluant le suivi de la conjoncture et l''analyse des politiques économiques ;</li>\r\n<li>maîtriser l''outil informatique et plus encore l''anglais ;</li>\r\n<li>pouvoir s''insérer rapidement dans le secteur du tourisme grâce aux connaissances conceptuelles et opérationnelles acquises ;</li>\r\n<li>construire une véritable progression de carrière à travers les différents métiers actuels et à venir.</li>\r\n</ul>', 'Ce mastère s''adresse à des diplômés titulaires de licences en économie\r\nou toutes formations équivalente à une licence du domaine économique et/ou de gestion. Toutefois, pour bien aborder ce mastère, des connaissances en management, marketing et micro-économie sont souhaitables.\r\n', 'Ces futurs professionnels de l''hôtellerie et du tourisme pourront, en raison des compétences acquises, postuler à des carrières dans les domaines suivants :\r\n<ul>\r\n\r\n<li>Institutions du tourisme : Assistant de direction de stations, d''offices de tourisme.</li>\r\n<li>Pays et collectivités territoriales : Gestionnaires espaces de loisirs, aménagement touristique, développeur touristique.</li>\r\n<li>Tour-Operatoring - Distribution - Promotion : Agent de fabrication, promotion et commercialisation de produits, Assistant de direction d''agences de voyages.</li>\r\n<li>Hôtellerie - Hébergements touristiques : Aide de directions générales, régionales, des ressources humaines, de la gestion des unités hôtelières ; chargés de mission ; résidences de tourisme, parcs de loisirs, commercial.</li>\r\n<li>Gestion de la restauration : Gestion de restaurants, Gestionnaire restauration d''unités hôtelières, commercial, chef de produits.</li>\r\n<li>Gestion et valorisation touristique du patrimoine culturel.</li>\r\n<li>Tourisme culturel.</li>\r\n</ul>'),
('12', 'MR', 9.9902, 'Economie Quantitative de l''Industrie', 'MR Eco Quanti Industrie', 33, 'Le mastère d’Economie quantitative de l’industrie et des réseaux vise à former des spécialistes de très haute compétence dans les domaines de l’analyse, de la modélisation et de la quantification  économique. Ils seront capables d’analyser les différentes formes d’organisation industrielle, les stratégies d’entreprises, les processus d’innovation et les effets des technologies  nouvelles.\r\n<br />\r\nCe Mastère propose ainsi un large panel de cours de techniques d’analyse quantitative (statistiques, économétrie, analyse de données, etc.) et consacre une part très importante aux aspects les plus récents de la théorie de l’organisation industrielle. C’est dans cette perspective que l’articulation entre la recherche et l’enseignement prend toute son importance.\r\n', 'Ce master s''adresse à des diplômés titulaires d''une Licence fondamentale en Economie, en gestion ou en informatique de gestion.\r\n<br />\r\nUne priorité est donnée aux étudiants de la Faculté des Sciences Economiques et de Gestion de Nabeul, mais la formation est ouverte aux candidats extérieurs ayant un niveau équivalent.\r\n<br />\r\nLa formation et ouverte aussi aux étudiants issus des écoles d’ingénieur ayant une formation équivalente en analyse économique (ESSAI, EPT (filière Economie et Gestion Scientifique, etc.)\r\n<br />\r\n25 étudiants sont prévu par an durant les quatre années d’habilitation.\r\n\r\n\r\n', 'Ce cursus peut déboucher sur la préparation d''une thèse et l''entrée dans une carrière universitaire d’enseignant-chercheur.\r\n<br />\r\nEn formant les étudiants aux principales méthodes d''analyse économétrique et statistiques utilisées dans les études économiques, cette formation entend répondre aux besoins d''analyse et d''expertise qu''expriment les différents types d''entreprises (banques, sociétés d''assurance, grandes entreprises industrielles et commerciales, petites et moyennes entreprises de services, bureaux d''étude et de conseil, etc.), les cabinets de consultants et un certain nombre d''organismes privés ou publics.\r\n<br />\r\nPour les meilleurs étudiants, ce cursus peut déboucher sur la préparation d''une thèse et l''entrée dans une carrière universitaire.'),
('13', 'LF', 6.62753, 'Gestion - Marketing', 'LF Gestion - Marketing', NULL, NULL, NULL, NULL),
('14', 'LF', 7.32519, 'Gestion - Finance', 'LF Gestion - Finance', NULL, NULL, NULL, NULL),
('15', 'LF', 7.83229, 'Gestion - Sciences Comptables', 'LF Gestion - Compta', NULL, NULL, NULL, NULL),
('16', 'LA', 8.80797, 'Informatique - Appliquée à la Gestion', 'LA Informatique - AG', NULL, 'La Licence appliquée en informatique de gestion a pour objectif de former, en trois ans après le\r\nbaccalauréat, des compétences ayant acquis à la fois une bonne connaissance en gestion ainsi que le sens stratégique nécessaire pour saisir les occasions d''affaires qu''offrent Internet et la nouvelle économie numérique. Ces compétences devront être en mesure de :\r\n<ul>\r\n<li>Concevoir et de réaliser des applications Web transactionnels,</li>\r\n<li>Proposer des solutions techniques pour la e-entreprise,</li>\r\n<li>Gérer toutes les formes d''échanges commerciaux numérisés (non seulement des transactions en ligne, les prestations de service, des actions relevant d''une stratégie de communication.</li>\r\n</ul>', NULL, 'Les possibilités d''insertion professionnelles sont très larges, elles concernent toutes les structures (entreprises, associations, administrations) qui souhaitent développer leur activité commerciale à l''aide de la dimension numérique.'),
('17', 'LF', 9.08881, 'Informatique - Appliquée à la Gestion', 'LF Informatique - AG', NULL, 'La Licence fondamentale en Informatique Appliquée à la Gestion a pour objectif de former, en trois ans, des compétences capables de seconder des ingénieurs dans des domaines tels que :\r\n<ul>\r\n<li>la conception, la réalisation et la programmation des systèmes\r\nd''information,</li>\r\n<li>l''automatisation des procédés de gestion des entreprises,</li>\r\n<li>Le contrôle et le suivi d''un projet informatique depuis l''étude des besoins jusqu''à sa mise en œuvre.</li>\r\n</ul>', NULL, 'Outre la possibilité d''intégrer les Mastères en informatique, les diplômés issus de cette formation pourront aussi occuper des emplois dans les entreprises ainsi que les sociétés de services et de développement de logiciels de gestion.\r\n<br />\r\nIls seront capables de participer à des tâches de réalisation, d''installation, d''exploitation et de maintenance évolutive ou curative.'),
('18', 'MR', 10.1152, 'Economie des Affaires', 'MR Economie Affaires', 100000071, 'Dans un monde très ouvert, l''entreprise a besoin d''un environnement institutionnel, naturel et international favorable pour mieux développer sa production tant en quantité qu''en qualité.\r\n<br />	\r\nL''amélioration de la compétitivité de l’entreprise est l''un des objectifs primordiaux de l''économie tunisienne. Dans le cadre de ce mastère, l''étudiant aura une formation sur les trois volets de l''environnement de l''entreprise : l''environnement institutionnel, l''environnement naturel (le développement durable) et l''environnement international.', 'Ce master s''adresse à des diplômés titulaires d''une Licence Fondamentale en Economie des Affaires, une Licence Fondamentale en Monnaie, Finances et Banques, une Licence Fondamentale en Economie Mathématique et Econométrie, ou toutes Licences Fondamentales Equivalentes des autres institutions.', NULL),
('19', 'MP', 9.54438, 'Logistique du Commerce International', 'MP Logistique Com Inter', 30, 'Ce mastère vise à répondre au besoin de formation des étudiants aux techniques logistiques liées au commerce international. Cette formation spécialisée permettra d''acquérir une double compétence théorique et technique dans les domaines de la logistique et des transports internationaux. \r\n<br />\r\nCe mastère peut répondre aux besoins des entreprises nationales exportatrices qui cherchent à renforcer leur compétitivité dans un monde globalisé, en développant des avantages compétitifs fondés sur la synchronisation de plusieurs activités dans le domaine du commerce extérieur, de la logistique et du transport.', 'Etre titulaire d''un diplôme de licence appliquée en sciences économiques, d''un diplôme de licence appliquée en économie et finance internationales, d''un diplôme de licence fondamentale en sciences économiques ou de diplômes équivalents.', 'Cette spécialité prépare les étudiants aux carrières professionnelles de cadres supérieurs dans tous les services commerciaux et logistiques des sociétés exportatrices et importatrices, sociétés de transport international (compagnies aériennes, maritimes...),  institutions financières (assurances, banques…) et toute institution intervenant dans une opération de commerce international (agents de douane, transitaires…). Avec une grande diversité dans l’étendue des fonctions et des responsabilités : responsable logistique, courtier d’affrètement, responsable import/export, responsable achat/transport, agent de transit, chef de projet, prestataire de services logistiques…  \r\n<br />\r\nPour les étudiants distingués, ce cursus peut déboucher sur la préparation d''une thèse et l''entrée dans une carrière universitaire.'),
('20', 'MP', 9.54445, 'Ingénierie des Systèmes d''Information et des Connaissances', 'MP Ing Syst Info Conn', 3, 'Cette formation se veut d’être bi-disciplinaire en s’articulant autour du management des systèmes d’information et de l’ingénierie des connaissances. Ainsi, elle cherche à développer chez les jeunes professionnels une expertise méthodologique et technique en informatique décisionnelle alliée à une faculté managériale des systèmes d’information. Ce caractère de double compétence - classiquement exclusif aux professionnels séniors à grandes expériences – apporte une forte valeur ajoutée scientifique, permet de gagner un véritable avantage compétitif sur le marché de l’emploi et prépare de façon prononcée à des carrières de haut niveau.\r\n\r\nSur l’aspect méthodologique et technique, la formation couvre un spectre décisionnel complet allant de l’entreposage et l’historisation des données jusqu’à l’implémentation des tableaux de bord tout en passant par la fouille de données, l’extraction, l’analyse, l’évaluation, la validation et la représentation des connaissances.\r\nQuant à l’aspect managérial, il se traduit par la conduite de la mise en place des systèmes d’information opérationnels et/ou décisionnels ainsi que la gestion des changements induits. Il couvre également le schéma directeur, l’urbanisation et l’architecture durant la conception et les standards, les facteurs de succès et les stratégies de déploiement, d’intégration et d’appropriation durant le cycle de vie d’un système d’information.\r\n\r\nOutre son contenu académique, le mastère ISIC a une orientation professionnelle très franche à travers l’intervention de professionnels confirmés et évoluant activement dans l''entreprise du décisionnel et des technologies de l’information. Ce choix rompt avec l’attitude universitaire cloisonnée, mettant la formation en liaison étroite avec le monde professionnel, lui donnant une capacité d’adaptation aux dernières évolutions technologiques et, par conséquent, lui permet d’être à l’écoute des vraies attentes du marché de l’emploi local et international.', 'Les candidats à cette formation sont essentiellement des étudiants titulaires d’une licence en Informatique ou en Informatique Appliquée à la Gestion. Les étudiants ayant une formation proche ou équivalente aux domaines de l’informatique, la gestion, l’économie, les mathématiques ou les mathématiques appliquées aux sciences sociales peuvent également accéder à la formation.\r\n\r\nLe mastère accueille 30 étudiants par promotion dont 6 environ pourront être des professionnels ou des étudiants issus d’institutions différentes de la FSEGN. Une priorité particulière est aussi accordée aux titulaires des licences appliquées (au dépend des licences fondamentales).\r\n\r\nLe recrutement est décidé par le comité pédagogique du mastère composé d’enseignants titulaires et de professionnels. La sélection des candidats se fait en fonction de leur niveau académique durant leur parcours universitaire (ou de leur expérience professionnelle). Cependant, une attention toute particulière est soigneusement accordée au projet et à la motivation personnelle de chaque candidat.', 'De sa nature bi-disciplinaire, le mastère ISIC permet à ces diplômés d’accéder à des métiers variés qui sont au cœur de l’informatique décisionnelle et des systèmes d’information. Ils peuvent ainsi prétendre à des postes de responsabilité dans les organismes nationaux et internationaux, dans les grandes entreprises, dans les petites et moyennes entreprises, mais aussi dans les organismes gouvernementaux.\r\n\r\nLe secteur des services est évidemment susceptible de présenter le plus de perspectives professionnelles. Pour n’en citer que les plus pertinentes, les diplômés du mastère ISIC peuvent intégrer : les bureaux d’étude d’ingénierie et de conseil ; les cabinets de consultation ; les entreprises commerciales ; les banques commerciales ; les assurances ; les agences publicitaires ; les sociétés de services informatiques ; et les institutions financières.\r\n\r\n<h2 style="margin-top:20px;">Plaquette du Mastère</h2>\r\n<a href="./documents/plaquette_isic_fr.pdf">\r\n<img src="documents/logo_isic_200.png" title="Version française de la plaquette du mastère ISIC" alt="Version française de la plaquette du Mastère ISIC" style="width:auto;" />\r\n</a>\r\n<p><a href="./documents/plaquette_isic_fr.pdf"><strong>Télécharger</strong> la plaquette du mastère ISIC</a></p>\r\n<div style="margin-top:20px;float:left;width:100%;">\r\n<div style="margin-right:5px;float:left;">\r\n<a href="http://www.facebook.com/mastere.isic">\r\n<img src="images/icons/fb_32.png" alt="Rejoignez la page facebook du Mastère ISIC" title="Rejoignez la page facebook du Mastère ISIC" />\r\n</a>\r\n</div>\r\n<div style="margin-top:6px;float:left;">\r\n<a href="http://www.facebook.com/mastere.isic">\r\n<strong>Rejoignez</strong> la page facebook du Mastère ISIC\r\n</a>\r\n</div>\r\n</div>');

-- --------------------------------------------------------

--
-- Table structure for table `submenu`
--

CREATE TABLE IF NOT EXISTS `submenu` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `menu_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `label` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `ord` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `submenu`
--

INSERT INTO `submenu` (`id`, `menu_id`, `label`, `status`, `ord`) VALUES
('authentication', 'home', 'User registration/authentication', 1, 3),
('framework', 'home', 'Building a Dynamic Web Site Framework', 1, 2),
('datatable', 'home', 'Interactive data table', 1, 3),
('thread', 'home', 'Discussion Thread', 1, 4),
('events', 'home', 'Event posting', 1, 6),
('file_management', 'home', 'File management', 1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `civility_id` int(11) DEFAULT NULL,
  `firstname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `birthdate` date DEFAULT NULL,
  `birthplace` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `office` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `street` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_id` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `login` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `pic_file` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status_id` tinyint(1) NOT NULL DEFAULT '1',
  `bio_en` text COLLATE utf8_unicode_ci,
  `bio_fr` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2012 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `civility_id`, `firstname`, `lastname`, `birthdate`, `birthplace`, `title`, `office`, `street`, `zipcode`, `city`, `country_id`, `email`, `phone`, `mobile`, `fax`, `login`, `password`, `pic_file`, `status_id`, `bio_en`, `bio_fr`) VALUES
(1, NULL, 'Unknown', 'User', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, 'user001', 'user001', 'thumb_default.png', 1, NULL, NULL),
(2, NULL, 'Ayoub', 'Ben Khiroun', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ayoub_abk@yahoo.fr', NULL, NULL, NULL, 'ayoub_abk@yahoo.fr', 'ayoub_abk@yahoo.fr', 'user002.jpg', 1, NULL, NULL),
(3, NULL, 'Mohamed Ali', 'Cherif', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'dalidali89@gmail.com', NULL, NULL, NULL, 'dalidali89@gmail.com', 'dalidali89@gmail.com', 'user002.jpg', 1, NULL, NULL),
(2009, NULL, 'Meriem', 'Ezzine', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ezzine.mariam@gmail.com', NULL, NULL, NULL, 'ezzine.mariam@gmail.com', 'ezzine.mariam@gmail.com', 'user004.jpg', 1, NULL, NULL),
(2010, NULL, 'Naouel', 'Ben Abda', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'naouel_ben_abda@yahoo.fr', NULL, NULL, NULL, 'naouel_ben_abda@yahoo.fr', 'naouel_ben_abda@yahoo.fr', 'user005.jpg', 1, NULL, NULL),
(2011, NULL, 'Narjes', 'Chouk', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'chicchoc88@gmail.com', NULL, NULL, NULL, 'chicchoc88@gmail.com', 'chicchoc88@gmail.com', 'user006.jpg', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `write_up`
--

CREATE TABLE IF NOT EXISTS `write_up` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `post_date` date NOT NULL,
  `post_time` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=46 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
